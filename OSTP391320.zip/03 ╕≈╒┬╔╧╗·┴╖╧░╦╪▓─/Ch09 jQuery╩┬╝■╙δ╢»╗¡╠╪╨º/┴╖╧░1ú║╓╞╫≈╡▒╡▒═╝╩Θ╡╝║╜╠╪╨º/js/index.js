$(document).ready(function(){
	/**主菜单鼠标移上时背景颜色加深**/

});