/**
 * Created by zongjuan.wang on 2016/6/1.
 */

/*关闭窗口*/
function close_plan(){
    
}
function collection(){
    
}
function del(){
   
}
function accounts(){
   
}