
/*关闭窗口*/
function close_plan(){
    
}
function collection(){
    
}
function del(){
    
}
function accounts(){
    
}

function minus(num){
    
}
function plus(num){
    
}
function total(){
    
}
total();