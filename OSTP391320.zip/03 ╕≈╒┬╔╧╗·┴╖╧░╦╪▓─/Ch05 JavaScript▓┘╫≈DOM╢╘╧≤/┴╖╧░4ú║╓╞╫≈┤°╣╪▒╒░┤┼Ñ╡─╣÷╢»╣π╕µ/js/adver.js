function adv_close(){
    document.getElementById("close").style.display="none";
    document.getElementById("float").style.display="none";
}

var closeTop;
var closeLeft;
var floatTop;
var floatLeft;
var closeObject;
var floatObject;
function place(){
    
}
function roll(){
   
}
window.onload=place;
window.onscroll=roll;