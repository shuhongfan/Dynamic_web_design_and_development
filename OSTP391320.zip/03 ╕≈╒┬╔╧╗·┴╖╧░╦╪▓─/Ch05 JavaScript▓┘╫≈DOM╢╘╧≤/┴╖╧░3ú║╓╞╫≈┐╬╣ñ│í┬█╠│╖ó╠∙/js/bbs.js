
function post(){
    document.getElementById("post").style.display="block";
}

var tou=new Array("tou01.jpg","tou02.jpg","tou03.jpg","tou04.jpg");
function postSuccess(){

}