// 定义年历生成函数
function calendar(y) {
    
    // 获取指定年份1月1日的星期数值
    var w = new Date(y, 0).getDay();

    var html = '<div class="box">';
    
     // 拼接每个月份的表格
  
    html += '</div>';
    return html;
}